$(function(){
  montaTh();
  pegaData();
});

var dataAtual = new Date();
var mes = dataAtual.getMonth();
var ano = dataAtual.getFullYear();
var diasNoMes = 32 - new Date(ano, mes, 32).getDate();

function pegaDiasDaSemana(dataAux, diasDaSemana){
  for(var i = 1;i < 7; i++){
    if (i == 1 && dataAux.getDay() != 0){
      diasDaSemana[dataAux.getDay() - 1] = dataAux.getDate() + "/" + (dataAux.getMonth() + 1) + "/" + dataAux.getFullYear();
    } else if(dataAux.getDay() == 6) {
      dataAux.setDate(dataAux.getDate() + 2);
      diasDaSemana[dataAux.getDay() - 1] = dataAux.getDate() + "/" + (dataAux.getMonth() + 1) + "/" + dataAux.getFullYear();
    } else {
      dataAux.setDate(dataAux.getDate() + 1);
      diasDaSemana[dataAux.getDay() - 1] = dataAux.getDate() + "/" + (dataAux.getMonth() + 1) + "/" + dataAux.getFullYear();
    }
  }
}
function montaTh(){
  var diasDaSemana = [];

  pegaDiasDaSemana(dataAtual, diasDaSemana);

  $("#diasDoMes th").each(function(idx, td) {
    if(idx != 0){
      td.append(diasDaSemana[idx - 1]);
    }
  });
}

function pegaData(){
  $(":radio").click(function() {
    var coluna = $(this).parent().parent().index();
    $("#diasDoMes th").each(function(idx, th) {
      if(idx == coluna){
        $("#diaDaConsulta").val($(th).text())
      }
    });
  });
}
