function showDiv() {
   texto = document.getElementById("pesquisar-aluno");
   botao = document.getElementById("botao-pesquisa");
   pesquisa = document.getElementById("pesquisa");
   // cancela = document.getElementById("cancela-pesquisa");

   texto.classList.add("mostra");
   botao.classList.add("mostra");
   pesquisa.classList.add("mostra");
   pesquisa.classList.add("pesquisa");
   // cancela.classList.add("mostra");
}
