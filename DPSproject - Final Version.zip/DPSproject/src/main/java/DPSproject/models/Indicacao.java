/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Classe que representa a Indicação do prontuário do DPS. 
 * 
 */

package DPSproject.models;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Indicacao {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private String encaminhamentoDescricao;
	@ElementCollection(fetch=FetchType.EAGER)
	@Enumerated
	private List<LocalizacaoProblema> localizacaoDoProblema = new LinkedList<LocalizacaoProblema>();
	@ElementCollection
	@Enumerated
	private List<Encaminhamento> encaminhamento = new LinkedList<Encaminhamento>();
	private String dependencias;
	@Column(length=1000)
	private String problemaDescricao;
	private String cid;
	@Enumerated
	private Desabafar desabafar;
	private String satisfacao;
	
	@OneToOne
	private Aluno aluno;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public List<Encaminhamento> getEncaminhamento() {
		return encaminhamento;
	}
	public void setEncaminhamento(List<Encaminhamento> encaminhamento) {
		this.encaminhamento = encaminhamento;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public Desabafar getDesabafar() {
		return desabafar;
	}
	public void setDesabafar(Desabafar desabafar) {
		this.desabafar = desabafar;
	}
	public String getSatisfacao() {
		return satisfacao;
	}
	public void setSatisfacao(String satisfacao) {
		this.satisfacao = satisfacao;
	}

	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public String getEncaminhamentoDescricao() {
		return encaminhamentoDescricao;
	}
	public void setEncaminhamentoDescricao(String encaminhamentoDescricao) {
		this.encaminhamentoDescricao = encaminhamentoDescricao;
	}
	public String getProblemaDescricao() {
		return problemaDescricao;
	}
	public void setProblemaDescricao(String problemaDescricao) {
		this.problemaDescricao = problemaDescricao;
	}
	public String getDependencias() {
		return dependencias;
	}
	public void setDependencias(String dependencias) {
		this.dependencias = dependencias;
	}
	public List<LocalizacaoProblema> getLocalizacaoDoProblema() {
		return localizacaoDoProblema;
	}
	public void setLocalizacaoDoProblema(List<LocalizacaoProblema> localizacaoDoProblema) {
		this.localizacaoDoProblema = localizacaoDoProblema;
	}
	
	public void addProblema(List<String> list) {
		
		for (String string : list) {
			localizacaoDoProblema.add(LocalizacaoProblema.valueOf(string));
		}
		
		
	}
	public void addEncaminhamento(List<String> asList) {
		for (String string : asList) {
			encaminhamento.add(Encaminhamento.valueOf(string));
		}
		
	}
}
