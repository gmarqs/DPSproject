/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Classe que representa o Professor.
 * 
 */


package DPSproject.models;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
public class Professor implements UserDetails{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Id;
	private int idade;
	private String nome;
	@DateTimeFormat
	private Calendar dataNascimento;
	//private String login;
	private String email;
	private String senha;
	private NivelUsuario nivelUsuario;
	private String numeroMatricula;
	@ManyToMany(fetch=FetchType.EAGER)
	private List<Curso> curso;
	@ManyToMany(fetch=FetchType.EAGER)
	private List<Roles> roles = new ArrayList<Roles>();
	
	  @OneToOne(cascade=CascadeType.REMOVE)
	  private Endereco endereco;
	  
	  @OneToMany(mappedBy="professor", cascade=CascadeType.REMOVE, fetch=FetchType.EAGER)
	  private List<Agenda> agenda;
	 
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}

	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public List<Curso> getCurso() {
		return curso;
	}
	public void setCurso(List<Curso> curso) {
		this.curso = curso;
	}

	  public Endereco getEndereco() { 
		  return endereco; 
	  } 
	  
	  public void setEndereco(Endereco endereco) { 
		  this.endereco = endereco; 
	}
	 
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getNumeroMatricula() {
		return numeroMatricula;
	}
	public void setNumeroMatricula(String numeroMatricula) {
		this.numeroMatricula = numeroMatricula;
	}

	public Calendar getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(Calendar dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	
	public List<Roles> getRoles() {
		return roles;
	}

	public void setRoles(List<Roles> roles) {
		this.roles = roles;
	}
	public List<Agenda> getAgenda() {
		return agenda;
	}
	public void setAgenda(List<Agenda> agenda) {
		this.agenda = agenda;
	}
	
	public void addAgenda(Agenda agenda) {
		this.agenda.add(agenda);
	}
	/*
	 * public String getLogin() { return login; } public void setLogin(String login)
	 * { this.login = login; }
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((senha == null) ? 0 : senha.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Professor other = (Professor) obj;
		if (senha == null) {
			if (other.senha != null)
				return false;
		} else if (!senha.equals(other.senha))
			return false;
		return true;
	}
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return this.roles;
	}
	@Override
	public String getPassword() {
		
		return this.senha;
	}
	@Override
	public String getUsername() {
		return this.email;
	}
	@Override
	public boolean isAccountNonExpired() {
	
		return true;
	}
	@Override
	public boolean isAccountNonLocked() {
	
		return true;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		
		return true;
	}
	@Override
	public boolean isEnabled() {
		
		return true;
	}
	
	public NivelUsuario getNivelUsuario() {
		return nivelUsuario;
	}
	public void setNivelUsuario(NivelUsuario nivelUsuario) {
		this.nivelUsuario = nivelUsuario;
	}
	@Override
	public String toString() {
		return "Professor [Id=" + Id + ", idade=" + idade + ", nome=" + nome + ", dataNascimento=" + dataNascimento
				+ ", email=" + email + ", senha=" + senha + ", nivelUsuario=" + nivelUsuario + ", numeroMatricula="
				+ numeroMatricula + "]";
	}
	
	
    

}
