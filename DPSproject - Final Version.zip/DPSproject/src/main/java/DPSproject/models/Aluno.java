/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe que representa um aluno.
 * 
 */


package DPSproject.models;

import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Aluno {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String nome;
	private String email;
	@Enumerated
	private Sexo sexo;
	@DateTimeFormat
	private Calendar dataNascimento;
	private int nivelUsuario;
	private String numeroMatricula;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn
	private Endereco endereco;
	private String telefone;
	@ManyToOne
	private Curso curso;
	private String dependencias;
	private Bolsa bolsadeEstudo;
	private String descricaoBolsa;
	@Enumerated
	private Periodo periodo;
	private int semestre;
	@OneToOne
	private Indicacao indicacao;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Endereco getEndereco() {
		return endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public String getDependencias() {
		return dependencias;
	}
	public void setDependencias(String dependencias) {
		this.dependencias = dependencias;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getNivelUsuario() {
		return nivelUsuario;
	}
	public void setNivelUsuario(int nivelUsuario) {
		this.nivelUsuario = nivelUsuario;
	}
	public String getNumeroMatricula() {
		return numeroMatricula;
	}
	public void setNumeroMatricula(String numeroMatricula) {
		this.numeroMatricula = numeroMatricula;
	}
	public Sexo getSexo() {
		return sexo;
	}
	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}
	public Calendar getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(Calendar dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public Periodo getPeriodo() {
		return periodo;
	}
	public void setPeriodo(Periodo periodo) {
		this.periodo = periodo;
	}
	public int getSemestre() {
		return semestre;
	}
	public void setSemestre(int semestre) {
		this.semestre = semestre;
	}
	public Bolsa getBolsadeEstudo() {
		return bolsadeEstudo;
	}
	public void setBolsadeEstudo(Bolsa bolsadeEstudo) {
		this.bolsadeEstudo = bolsadeEstudo;
	}
	public String getDescricaoBolsa() {
		return descricaoBolsa;
	}
	public void setDescricaoBolsa(String descricaoBolsa) {
		this.descricaoBolsa = descricaoBolsa;
	}
	
	public Indicacao getIndicacao() {
		return indicacao;
	}
	public void setIndicacao(Indicacao indicacao) {
		this.indicacao = indicacao;
	}

}
