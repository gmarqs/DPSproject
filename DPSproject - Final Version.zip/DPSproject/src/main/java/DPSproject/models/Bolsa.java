/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Enum que identifica se um aluno é bolsista ou não.
 * 
 */

package DPSproject.models;

public enum Bolsa {
	SIM,NAO

}
