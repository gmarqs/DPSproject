/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Enum que representa por quem o @Aluno foi encaminhado.
 * 
 */

package DPSproject.models;

public enum Encaminhamento {
	PROFESSOR,DIRETOR,COORDENADOR,COLEGA,FAMILIA,OUTROS

}
