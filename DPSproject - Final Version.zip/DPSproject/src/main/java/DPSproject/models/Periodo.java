/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Enum que determina os tipos de período possíveis do @Aluno.
 * 
 */

package DPSproject.models;

public enum Periodo {
	MANHA,TARDE,NOITE

}
