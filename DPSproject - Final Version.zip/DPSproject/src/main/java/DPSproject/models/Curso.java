/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Classe que representa os Cursos da universidade. 
 * Devem ser préviamente cadastrados no banco de dados utilizando a função criaCursos(),
 * da classe CursoDAO.
 * 
 */


package DPSproject.models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Curso {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Id;
	private String nome;
	private String campus;
	@OneToMany(mappedBy="curso")
	private List<Aluno> aluno;
	@ManyToMany
	private List<Professor> professor;
	
	
	
	public Curso(String nome, String campus) {
		this.nome = nome;
		this.campus = campus;
	}
	
	public Curso() {
		
		
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		this.Id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCampus() {
		return campus;
	}
	public void setCampus(String campus) {
		this.campus = campus;
	}


}
