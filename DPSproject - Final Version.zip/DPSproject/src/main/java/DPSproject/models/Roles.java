/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Classe que representa o nível de acesso ao sistema.
 * 
 */


package DPSproject.models;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.security.core.GrantedAuthority;
@Entity
public class Roles implements GrantedAuthority{
	

	private static final long serialVersionUID = 1L;
	@Id
	private String nome;
	
	public Roles() {
		
	}
	
	public Roles(String nome) {
		this.nome = nome;
		
	}
	

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override
	public String getAuthority() {
	
		return this.nome;
	}
	
	

}
