/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Enum que guarda a informação da view se o aluno tem algo para desabafar.
 * 
 */

package DPSproject.models;

public enum Desabafar {
	SIM,NAO

}
