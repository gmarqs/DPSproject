/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Enum que representa os tipos possíveis de Sexo.
 * 
 */

package DPSproject.models;

public enum Sexo {
	M,F
	
	

}
