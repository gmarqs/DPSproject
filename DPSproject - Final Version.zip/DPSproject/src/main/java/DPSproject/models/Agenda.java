/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe que representa a agenda de cada dia da semana dos professores.
 * Cada professor, possui 6 agendas, que representam cada dia da seamana.
 * 
 */


package DPSproject.models;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Agenda {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int diaDaSemana;
	@ElementCollection(fetch = FetchType.EAGER)
	private Set<Integer> horarios = new LinkedHashSet<>();
	@ManyToOne
	private Professor professor;
	
	@JoinColumn
	@OneToMany(fetch = FetchType.EAGER, cascade=CascadeType.REMOVE)
	private List<Consulta> consulta = new ArrayList<>();
	
	
	
	public Agenda(int diaDaSemana, Professor prof) {
		this.diaDaSemana = diaDaSemana;
		this.professor = prof;
	}
	
	public Agenda() {
		
	}
	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}

	public int getDiaDaSemana() {
		return diaDaSemana;
	}

	public void setDiaDaSemana(int diaDaSemana) {
		this.diaDaSemana = diaDaSemana;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public List<Consulta> getConsulta() {
		return consulta;
	}

	public void setConsulta(List<Consulta> consulta) {
		this.consulta = consulta;
	}

	public Set<Integer> getHorarios() {
		return horarios;
	}

	public void setHorarios(Set<Integer> horarios) {
		this.horarios = horarios;
	}

	public void addHorario(int horario) {
		horarios.add(horario);
	}
	
	public void addConsulta(Consulta consulta) {
		this.consulta.add(consulta);
	}

	@Override
	public String toString() {
		return "Agenda [id=" + id + ", diaDaSemana=" + diaDaSemana + ", horarios=" + horarios + ", professor="
				+ professor.getId() + "]";
	}

}
