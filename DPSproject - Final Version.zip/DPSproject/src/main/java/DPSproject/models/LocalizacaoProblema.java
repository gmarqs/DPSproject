/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Enum que determina os tipos de problemas possíveis do @Aluno.
 * 
 */

package DPSproject.models;

public enum LocalizacaoProblema {
	ACADEMICO,PROFISSIONAL,FAMILIAR,PESSOAL,FINANCEIRO,PEDAGOGICO,PSICOLOGICO,SAUDE,BOLSA,CURSO,DEFICIENCIA,
	OUTROS,VAZIO

}
