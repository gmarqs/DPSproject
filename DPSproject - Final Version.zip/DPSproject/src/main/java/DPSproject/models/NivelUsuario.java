/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Enum que determina os níveis de acesso do @Professor.
 * 
 */
package DPSproject.models;

public enum NivelUsuario {
	ROLE_ADMIN,ROLE_USER

}
