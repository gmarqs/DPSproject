/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * DAO da Indicação.
 * 
 */


package DPSproject.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import DPSproject.models.Aluno;
import DPSproject.models.Indicacao;
@Transactional
@Repository
public class IndicacaoDAO {
	
	@PersistenceContext
	private EntityManager em;
	
	/**
	 * Cadastra a Indicação no sistema
	 * @param indicacao
	 */
	public void cadastrarIndicacao(Indicacao indicacao) {
		em.persist(indicacao);
	}
	/**
	 * Vincula no Aluno, a indicação.
	 * @param aluno
	 * @param indicacao
	 */
	public void vinculaAluno(Aluno aluno, Indicacao indicacao) {
		
		Indicacao a = em.find(Indicacao.class, indicacao.getId());
		a.setAluno(aluno);
	}
	
	

}
