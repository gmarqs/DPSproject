/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * DAO do Prontuário.
 * 
 */


package DPSproject.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import DPSproject.models.Aluno;
import DPSproject.models.Professor;
import DPSproject.models.Prontuario;

@Transactional
@Repository
public class ProntuarioDAO {
	
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	private AlunoDAO alunodao;
	
	/**
	 * Cadastra um Prontuário no sistema.
	 * @param prontuario
	 */
 	public void cadastraProntuario(Prontuario prontuario) {
		em.persist(prontuario);
	}
 	
 	/**
 	 * Vincula um Aluno no Prontuário
 	 * @param prontuario
 	 * @param aluno
 	 */
 	
 	public void vinculaAluno(Prontuario prontuario, Aluno aluno) {
 		prontuario.setAluno(aluno);
 	}
 	
 	
 	/**
 	 * Retorna a lista de Prontuários de um determinado Aluno.
 	 * @param matricula
 	 * @return List<Prontuario>
 	 */
 	public List<Prontuario> retornaProntuarios(String matricula) {
 		Aluno aluno = alunodao.BuscaAlunoMatricula(matricula);
 		List<Prontuario> prontuario = em.createQuery("select p from Prontuario p join fetch p.aluno a where a = :aluno",Prontuario.class)
 				.setParameter("aluno", aluno).getResultList();
 		
 	    return prontuario;
 	}
 	
 	/**
 	 * Retorna o prontuário passado por parâmetro.
 	 * @param id
 	 * @return Prontuario
 	 */
 	public Prontuario chamaProntuario(int id) {
 		Prontuario prontuario = em.createQuery("select p from Prontuario p where p.id = :id",Prontuario.class)
 				.setParameter("id", id).getSingleResult();
 	
 		
 		return prontuario;
 	}
 	
 	
 	

}
