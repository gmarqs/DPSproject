/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * DAO do Professor.
 * 
 */

package DPSproject.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import DPSproject.models.Agenda;
import DPSproject.models.Consulta;
import DPSproject.models.Endereco;
import DPSproject.models.Professor;
import DPSproject.models.Roles;

@Repository
@Transactional
public class ProfessorDAO implements UserDetailsService {
	@PersistenceContext
	private EntityManager em;
	
	/**
	 * Cadastra um Professor no sistema.
	 * @param professor
	 */

	@CacheEvict(value="cacheProf",allEntries=true)
	public void cadastrarProfessor(Professor professor) {

		em.persist(professor);

	}

	/**
	 * Vincula um Endereço no Professor.
	 * @param professor
	 * @param endereco
	 */
	public void vinculaEndereco(Professor professor, Endereco endereco) {

		Professor prof = em.find(Professor.class, professor.getId());
		prof.setEndereco(endereco);
	}

	/**
	 * Deleta um Professor do sistema.
	 * @param id
	 */
	public void excluirProfessor(int id) {
		Professor professor = em.find(Professor.class, id);
		em.remove(professor);

	
	}

	/**
	 * Método que faz a autenticação do login para acessar o sistema.
	 */
	public UserDetails loadUserByUsername(String email) {

		Professor professor;
		professor = em.createQuery("select p from Professor p where p.email = :email", Professor.class)
				.setParameter("email", email)/* .setParameter("senha", senha) */.getSingleResult();

		if (professor == null) {
			throw new UsernameNotFoundException("O usuário " + email + " não foi encontrado");
		}

		return professor;
	}

	/**
	 * Vincula o tipo de acesso ao sistema, com base no seu cadastro.
	 * @param professor
	 */
	public void vinculaRoles(Professor professor) {
		Professor p = em.find(Professor.class, professor.getId());
		if (p.getNivelUsuario().name().equals("ROLE_ADMIN")) {
			Roles role = em.find(Roles.class, "ROLE_ADMIN");
			p.getRoles().add(role);
		} else {
			Roles role = em.find(Roles.class, "ROLE_USER");
			p.getRoles().add(role);
		}
	}
/**
 * Método utilizado para criar um tipo de acesso ao sistema.
 * @param role
 */
	public void criaRole(Roles role) {
		em.persist(role);
	}

	/**
	 * Cria a agenda no sistema.
	 * @param agenda
	 */
	public void cadastraAgenda(Agenda agenda) {
		em.persist(agenda);

	}

	/**
	 * Busca um Professor no sistema pelo seu e-mail.
	 * @param email
	 * @return Professor
	 */
	@Cacheable(value="cacheProf")
	public Professor BuscaProfessorEmail(String email) {
		Professor professor = em.createQuery("select p from Professor p where p.email = :email", Professor.class)
				.setParameter("email", email).getSingleResult();

		return professor;
	}

	/**
	 * Verifica se o Professor já possui alguma agenda cadastrada.
	 * @param professor
	 * @return
	 */
	/*
	public boolean verificaAgenda(Professor professor) {
		List<Professor> professor2 = em
				.createQuery("select p from Professor p join fetch p.agenda a where p = :professor", Professor.class)
				.setParameter("professor", professor).getResultList();

		if (professor2.isEmpty()) {
			return false;
		}
		return true;
	}*/

	/**
	 * Atualiza os dados da Agenda.
	 * @param agenda
	 */
	public void merge(Agenda agenda) {
		em.merge(agenda);
	}
	
	/**
	 * Retorna um Professor
	 * @param id
	 * @return Professor
	 */
	@Cacheable(value="cacheProf")
	public Professor getProfessor(int id) {
		return em.find(Professor.class, id);
	}
	
	/**
	 * Retorna uma lista de professores.
	 * @return List<Professor>
	 */
	public List<Professor> buscaProfessores() {

		return em.createQuery("select p from Professor p", Professor.class).getResultList();

	}
/**
 * Atualiza os dados do Professor.
 * @param professor
 */
	public void merge(Professor professor) {
		em.merge(professor);

	}
	/**
	 * Cadastra uma nova consulta no sistema.
	 * @param consulta
	 */
	@CacheEvict(value="consultaCache", allEntries=true)
	public void cadastraConsulta(Consulta consulta) {
		em.persist(consulta);
	}
	
    /**
     * Quando o Professor é criado, esse método é chamado para criar as Agendas dele
     * para cada dia da semana.
     * @param professor
     */
	public void criaAgendas(Professor professor) {
		Professor prof = em.find(Professor.class, professor.getId());
		
		Agenda agenda1 = new Agenda(2,prof);
		Agenda agenda2 = new Agenda(3,prof);
		Agenda agenda3 = new Agenda(4,prof);
		Agenda agenda4 = new Agenda(5,prof);
		Agenda agenda5 = new Agenda(6,prof);
		Agenda agenda6 = new Agenda(7,prof);
			
		em.persist(agenda1);
		em.persist(agenda2);
		em.persist(agenda3);
		em.persist(agenda4);
		em.persist(agenda5);
		em.persist(agenda6);
		
		prof.addAgenda(agenda1);
		prof.addAgenda(agenda2);
		prof.addAgenda(agenda3);
		prof.addAgenda(agenda4);
		prof.addAgenda(agenda5);
		prof.addAgenda(agenda6);
	
		
	}
	
	/**
	 * Obtém uma lista de Professores que já tem um dia disponível para consulta.
	 * @return List<Professor>
	 */
	public List<Professor> getProfessores() {
		return em.createQuery("select distinct p from Professor p join fetch p.agenda a join fetch a.horarios h "
				+ "where h is not null", Professor.class)
				.getResultList();
		
	}

}
