/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * DAO do Curso. 
 * Obs: Cursos são criados préviamente pelo desenvolvedor.
 * 
 */

package DPSproject.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import DPSproject.models.Curso;

@Transactional
@Repository
public class CursoDAO {
	
	@PersistenceContext
	private EntityManager em;
	/**
	 * Retorna a lista de Cursos cadastrados.
	 * @return List<Curso>
	 */
	@SuppressWarnings("unchecked")
	@Cacheable(value="cacheCurso")
	public List<Curso> lista(){
		Session s = em.unwrap(Session.class);
		Criteria c = s.createCriteria(Curso.class);
		
		return (List<Curso>) c.list();
	}
	/**
	 * Método para criar os Cursos no banco de dados.
	 */
	public void criaCursos() {
		em.persist(new Curso("Administração","D. Idilio"));
		em.persist(new Curso("Arquitetura e Urbanismo","Boqueirão"));
		em.persist(new Curso("Ciência da Computação","D. Idilio"));
		em.persist(new Curso("Ciências Biológicas","D. Idilio"));
		em.persist(new Curso("Ciências Contábeis","D. Idilio"));
		em.persist(new Curso("Ciências Econômicas","D. Idilio"));
		em.persist(new Curso("Cinema e Audiovisual","D. Idilio"));
		em.persist(new Curso("Direito","Boqueirão"));
		em.persist(new Curso("Enfermagem","D. Idilio"));
		em.persist(new Curso("Engenharia Ambiental","D. Idilio"));
		em.persist(new Curso("Engenharia Civil","D. Idilio"));
		em.persist(new Curso("Engenharia de Produção","D. Idilio"));
		em.persist(new Curso("Engenharia Mecânica","D. Idilio"));
		em.persist(new Curso("Engenharia Química","D. Idilio"));
		em.persist(new Curso("Farmácia","D. Idilio"));
		em.persist(new Curso("Filosofia","D. Idilio"));
		em.persist(new Curso("Gastronomia","D. Idilio"));
		em.persist(new Curso("Jornalismo","D. Idilio"));
		em.persist(new Curso("Letras/Inglês","D. Idilio"));
		em.persist(new Curso("Matemática","D. Idilio"));
		em.persist(new Curso("Música","D. Idilio"));
		em.persist(new Curso("Nutrição","D. Idilio"));
		em.persist(new Curso("Pedagogia","D. Idilio"));
		em.persist(new Curso("Produção Multimídia","D. Idilio"));
		em.persist(new Curso("Psicologia","D. Idilio"));
		em.persist(new Curso("Publicidade e Propaganda","D. Idilio"));
		em.persist(new Curso("Química","D. Idilio"));
		em.persist(new Curso("Relações Internacionais","D. Idilio"));
		em.persist(new Curso("Relações Públicas","D. Idilio"));
		em.persist(new Curso("Sistemas de Informação","D. Idilio"));
		em.persist(new Curso("Teologia","D. Idilio"));
		em.persist(new Curso("Tradução e Interpretação","D. Idilio"));
		em.persist(new Curso("Outros","Outros"));
		
		
	}
	
	public Curso pegaCurso(int id) {
		
		return em.find(Curso.class, id);
		
	}
	

}
