/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * DAO do Endereço.
 * 
 */

package DPSproject.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import DPSproject.models.Aluno;
import DPSproject.models.Endereco;
import DPSproject.models.Professor;

@Repository
@Transactional
public class EnderecoDAO {
	
	
	@PersistenceContext
	private EntityManager em;
	
	/**
	 * Cadastra um Endereço no sistema.
	 * @param endereco
	 */
	public void cadastraEndereco(Endereco endereco) {
		
		em.persist(endereco);
	}

	/**
	 * Vincula um Professor no Endereço.
	 * @param professor
	 * @param endereco
	 */
	public void vinculaProfessor(Professor professor, Endereco endereco) {
		
		Endereco end = em.find(Endereco.class, endereco.getId());
		end.setProfessor(professor);
		
	}
	
	public void vinculaAluno(Aluno aluno, Endereco endereco) {
		
		Endereco end = em.find(Endereco.class, endereco.getId());
		//end.setAluno(aluno);
		
	}
	
	/**
	 * Busca um Endereço pelo aluno passado por parâmetro.
	 * @param aluno
	 * @return Endereco
	 */
	public Endereco pegaEnderecoPeloAluno(Aluno aluno) {
		Endereco endereco = em.createQuery("select e from Endereco e join fetch e.aluno a where a = :aluno", Endereco.class)
		.setParameter("aluno", aluno).getSingleResult();
		
		return endereco;
		
	}
	
	/**
	 * Busca um Endereco pelo Id. 
	 * @param id
	 * @return Endereco
	 */
	public Endereco getEndereco(int id) {
		
		return em.find(Endereco.class, id);
	}

	/**
	 * Atualiza os dados do Endereço.
	 * @param endereco
	 */
	public void merge(Endereco endereco) {
		em.merge(endereco);
		
	}
	

}
