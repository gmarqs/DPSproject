/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * DAO da Agenda.
 * 
 */

package DPSproject.dao;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import DPSproject.models.Agenda;
import DPSproject.models.Consulta;
import DPSproject.models.Professor;

@Transactional
@Repository
public class AgendaDAO {

	@PersistenceContext
	private EntityManager em;

	/**
	 * Retorna a agenda do professor de um determinado dia da semana.
	 * @param dia
	 * @param id
	 * @return Agenda
	 */
	public Agenda retornaAgenda(int dia, int id) {

		Agenda agenda = em
				.createQuery("select a from Agenda a join fetch a.professor p where "
						+ "a.diaDaSemana = :dia and p.id = :id", Agenda.class)
				.setParameter("dia", dia).setParameter("id", id).getSingleResult();

		return agenda;

	}

	/**
	 * Atualiza as informações da Agenda.
	 * @param agenda
	 */
	public void merge(Agenda agenda) {
		em.merge(agenda);
	}


/**
 * Pega a agenda da segunda-feira de um determinado professor e exclui as consultas futuras que 
 * já estão marcadas, mostrando na view apenas os dias e horários disponíveis.
 * @param number
 * @return Agenda
 */
	public Agenda getSegunda(int number) {
		Professor professor = em.find(Professor.class, number);

		Agenda agenda = em
				.createQuery("select a from Agenda a join fetch a.professor p where p = :professor and "
						+ "a.diaDaSemana = :dia", Agenda.class)
				.setParameter("professor", professor).setParameter("dia", 2).getSingleResult();

		Set<Integer> set = new LinkedHashSet<>(agenda.getHorarios());
		Agenda a = new Agenda();
		a.setHorarios(set);

		Calendar calendar = Calendar.getInstance();

		List<Consulta> consultas = em
				.createQuery("select c from Consulta c join fetch c.professor p where c.diaDaSemana = 2 and "
						+ "p = :professor and c.data >= :calendar and c.status = 'Ativo'", Consulta.class)
				.setParameter("professor", professor).setParameter("calendar", calendar)
				.getResultList();
		for (Consulta consulta : consultas) {
			Integer horario = consulta.getHorario();
			a.getHorarios().remove(horario);

		}

		return a;

	}
	/**
	 * Pega a agenda da terça-feira de um determinado professor e exclui as consultas futuras que 
	 * já estão marcadas, mostrando na view apenas os dias e horários disponíveis.
	 * @param number
	 * @return Agenda
	 */
	public Agenda getTerca(int number) {
		Professor professor = em.find(Professor.class, number);

		Agenda agenda = em
				.createQuery("select a from Agenda a join fetch a.professor p where p = :professor and "
						+ "a.diaDaSemana = :dia", Agenda.class)
				.setParameter("professor", professor).setParameter("dia", 3).getSingleResult();

		Set<Integer> set = new LinkedHashSet<>(agenda.getHorarios());
		Agenda a = new Agenda();
		a.setHorarios(set);

		Calendar calendar = Calendar.getInstance();

		List<Consulta> consultas = em
				.createQuery("select c from Consulta c join fetch c.professor p where c.diaDaSemana = 3 and "
						+ "p = :professor and c.data >= :calendar and c.status = 'Ativo'", Consulta.class)
				.setParameter("professor", professor).setParameter("calendar", calendar)
				.getResultList();
		for (Consulta consulta : consultas) {
			Integer horario = consulta.getHorario();
			a.getHorarios().remove(horario);

		}

		return a;

	}
	/**
	 * Pega a agenda da quarta-feira de um determinado professor e exclui as consultas futuras que 
	 * já estão marcadas, mostrando na view apenas os dias e horários disponíveis.
	 * @param number
	 * @return Agenda
	 */
	public Agenda getQuarta(int number) {
		Professor professor = em.find(Professor.class, number);

		Agenda agenda = em
				.createQuery("select a from Agenda a join fetch a.professor p where p = :professor and "
						+ "a.diaDaSemana = :dia", Agenda.class)
				.setParameter("professor", professor).setParameter("dia", 4).getSingleResult();

		Set<Integer> set = new LinkedHashSet<>(agenda.getHorarios());
		Agenda a = new Agenda();
		a.setHorarios(set);

		Calendar calendar = Calendar.getInstance();

		List<Consulta> consultas = em
				.createQuery("select c from Consulta c join fetch c.professor p where c.diaDaSemana = 4 and "
						+ "p = :professor and c.data >= :calendar and c.status = 'Ativo'", Consulta.class)
				.setParameter("professor", professor).setParameter("calendar", calendar)
				.getResultList();
		for (Consulta consulta : consultas) {
			Integer horario = consulta.getHorario();
			a.getHorarios().remove(horario);

		}

		return a;

	}
	/**
	 * Pega a agenda da quinta-feira de um determinado professor e exclui as consultas futuras que 
	 * já estão marcadas, mostrando na view apenas os dias e horários disponíveis.
	 * @param number
	 * @return Agenda
	 */
	public Agenda getQuinta(int number) {
		Professor professor = em.find(Professor.class, number);

		Agenda agenda = em
				.createQuery("select a from Agenda a join fetch a.professor p where p = :professor and "
						+ "a.diaDaSemana = :dia", Agenda.class)
				.setParameter("professor", professor).setParameter("dia", 5).getSingleResult();

		Set<Integer> set = new LinkedHashSet<>(agenda.getHorarios());
		Agenda a = new Agenda();
		a.setHorarios(set);

		Calendar calendar = Calendar.getInstance();

		List<Consulta> consultas = em
				.createQuery("select c from Consulta c join fetch c.professor p where c.diaDaSemana = 5 and "
						+ "p = :professor and c.data >= :calendar and c.status = 'Ativo'", Consulta.class)
				.setParameter("professor", professor).setParameter("calendar", calendar)
				.getResultList();
		for (Consulta consulta : consultas) {
			Integer horario = consulta.getHorario();
			a.getHorarios().remove(horario);

		}

		return a;

	}
	/**
	 * Pega a agenda da sexta-feira de um determinado professor e exclui as consultas futuras que 
	 * já estão marcadas, mostrando na view apenas os dias e horários disponíveis.
	 * @param number
	 * @return Agenda
	 */
	public Agenda getSexta(int number) {
		Professor professor = em.find(Professor.class, number);

		Agenda agenda = em
				.createQuery("select a from Agenda a join fetch a.professor p where p = :professor and "
						+ "a.diaDaSemana = :dia", Agenda.class)
				.setParameter("professor", professor).setParameter("dia", 6).getSingleResult();

		Set<Integer> set = new LinkedHashSet<>(agenda.getHorarios());
		Agenda a = new Agenda();
		a.setHorarios(set);

		Calendar calendar = Calendar.getInstance();

		List<Consulta> consultas = em
				.createQuery("select c from Consulta c join fetch c.professor p where c.diaDaSemana = 6 and "
						+ "p = :professor and c.data >= :calendar and c.status = 'Ativo'", Consulta.class)
				.setParameter("professor", professor).setParameter("calendar", calendar)
				.getResultList();

		for (Consulta consulta : consultas) {
			Integer horario = consulta.getHorario();
			a.getHorarios().remove(horario);

		}

		return a;

	}
	/**
	 * Pega a agenda da sábado-feira de um determinado professor e exclui as consultas futuras que 
	 * já estão marcadas, mostrando na view apenas os dias e horários disponíveis.
	 * @param number
	 * @return Agenda
	 */
	public Agenda getSabado(int number) {
		Professor professor = em.find(Professor.class, number);
		Agenda agenda = em
				.createQuery("select a from Agenda a join fetch a.professor p where p = :professor and "
						+ "a.diaDaSemana = :dia", Agenda.class)
				.setParameter("professor", professor).setParameter("dia", 7).getSingleResult();

		Set<Integer> set = new LinkedHashSet<>(agenda.getHorarios());
		Agenda a = new Agenda();
		a.setHorarios(set);
		for (Integer integer : a.getHorarios()) {
			System.out.println("tem horario aqui sim " + integer);
		}

		Calendar calendar = Calendar.getInstance();

		List<Consulta> consultas = em
				.createQuery("select c from Consulta c join fetch c.professor p where c.diaDaSemana = 7 and "
						+ "p = :professor and c.data >= :calendar and c.status = 'Ativo'", Consulta.class)
				.setParameter("professor", professor).setParameter("calendar", calendar) .getResultList();
		for (Consulta consulta : consultas) {
			Integer horario = consulta.getHorario();
			System.out.println("entramos deletando");
			a.getHorarios().remove(horario);

		}

		return a;

	}
	
	/**
	 * Retorna a lista de consultas marcadas para um determinado professor a partir da data atual.
	 * @param professor
	 * @return List<Consulta>
	 */
    @Cacheable(value="consultaCache")
	public List<Consulta> getConsultas(Professor professor) {

		Calendar calendar = Calendar.getInstance();
		List<Consulta> consultas = em.createQuery(
				"select c from Consulta c join fetch c.professor p where p = :professor and c.data >= :calendar and c.status = 'Ativo'",
				Consulta.class).setParameter("professor", professor).setParameter("calendar", calendar).getResultList();

		return consultas;

	}

	public void mergeConsulta(Consulta consulta) {
		em.merge(consulta);
	}
	
	public Consulta getConsulta(int id) {
		return em.find(Consulta.class, id);
	}

}
