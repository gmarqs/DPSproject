/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * DAO do Aluno.
 * 
 */

package DPSproject.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import DPSproject.models.Aluno;
import DPSproject.models.Curso;
import DPSproject.models.Endereco;
import DPSproject.models.Indicacao;
import DPSproject.models.LocalizacaoProblema;

@Transactional
@Repository
public class AlunoDAO {
	
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	private CursoDAO cursoDAO;
	
	public void cadastrarAluno(Aluno aluno) {
		em.persist(aluno);
		
	}
	
	/**
	 * Vincula o endereço com o Aluno na hora do cadastro de um novo Aluno no sistema.
	 * @param aluno
	 * @param endereco
	 */
	public void vinculaEndereco(Aluno aluno, Endereco endereco) {
		Endereco e = em.find(Endereco.class, endereco.getId());
		Aluno a = em.find(Aluno.class, aluno.getId());
		a.setEndereco(e);
	}
	
	/**
	 * Vincula a indicação com o Aluno na hora do cadastro de um novo Aluno no sistema.
	 * @param aluno
	 * @param indicacao
	 */
	public void vinculaIndicacao(Aluno aluno, Indicacao indicacao) {
		
		Aluno a = em.find(Aluno.class, aluno.getId());
		a.setIndicacao(indicacao);
	}
	
	/**
	 * Busca um Aluno no sistema.
	 * @param id
	 * @return Aluno
	 */
	public Aluno BuscaAluno(int id) {
		return em.find(Aluno.class, id);
	}

	/**
	 * Vincula um curso com o Aluno.
	 * Cursos já são préviamente cadastrados no sistema pelo desenvolvedor.
	 * @param aluno
	 * @param curso
	 */
	public void vinculaCurso(Aluno aluno, Curso curso) {
		Aluno a =  em.find(Aluno.class, aluno.getId());
	     a.setCurso(curso);

	}
	/**
	 * Busca um Aluno pelo seu número de matrícula.
	 * @param matricula
	 * @return Aluno
	 */
	public Aluno BuscaAlunoMatricula(String matricula) {
		Session s = em.unwrap(Session.class);
		Criteria c = s.createCriteria(Aluno.class);
		
		c.add(Restrictions.like("numeroMatricula", matricula));
		
		return (Aluno) c.uniqueResult();
	}
	
	/**
	 * Busca os Alunos por um determinado Curso e/ou Indicação.
	 * @param problema
	 * @param cursoId
	 * @return List<Aluno> 
	 */
	public List<Aluno> buscaAlunosCurso(LocalizacaoProblema problema, int cursoId){
		Curso curso = cursoDAO.pegaCurso(cursoId);
		if(cursoId != 0  && problema == null) {
		List<Aluno> alunoList = em.createQuery("select a from Aluno a join fetch a.curso c where c = :curso",Aluno.class)
		.setParameter("curso", curso).getResultList();
		
		return alunoList;
		}else if(cursoId == 0 && problema != null) {
		List<Aluno> alunoList = em.createQuery("select a from Aluno a join fetch a.indicacao i join fetch i.localizacaoDoProblema ii"
				+ " where ii = :problema",Aluno.class)
				.setParameter("problema", problema).getResultList();
		    return alunoList;
		
		}
		
	    List<Aluno> alunoList = em.createQuery("select a from Aluno a join fetch a.indicacao i join fetch i.localizacaoDoProblema ii "
	    		+ "join fetch a.curso c where c = :curso"
	    		+ " and ii = :problema",Aluno.class)
	    		.setParameter("problema",problema)
	    		.setParameter("curso", curso).getResultList();
		
		return alunoList;

	}
/**
 * Atualiza os dados do Aluno.
 * @param a
 */
	public void merge(Aluno a) {
		em.merge(a);
		
	}


	
	

}