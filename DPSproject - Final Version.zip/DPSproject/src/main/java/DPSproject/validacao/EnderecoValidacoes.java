package DPSproject.validacao;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import DPSproject.models.Endereco;



public class EnderecoValidacoes implements Validator  {

	@Override
	public boolean supports(Class<?> clazz) {
		
		return Endereco.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmpty(errors, "numero", "field.required");
		ValidationUtils.rejectIfEmpty(errors, "rua", "field.required");
		ValidationUtils.rejectIfEmpty(errors, "cep", "field.required");
		ValidationUtils.rejectIfEmpty(errors, "municipio", "field.required");
		ValidationUtils.rejectIfEmpty(errors, "bairro", "field.required");
		ValidationUtils.rejectIfEmpty(errors, "estado", "field.required");
		
		
		
	}

}
