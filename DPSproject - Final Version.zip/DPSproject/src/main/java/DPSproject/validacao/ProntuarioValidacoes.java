package DPSproject.validacao;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import DPSproject.models.Prontuario;

public class ProntuarioValidacoes implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		
		return Prontuario.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmpty(errors, "descricao", "field.required");
		

	}

}
