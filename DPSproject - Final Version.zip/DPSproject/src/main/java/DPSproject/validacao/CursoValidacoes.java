package DPSproject.validacao;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import DPSproject.models.Curso;

public class CursoValidacoes implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Curso.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		Curso curso = (Curso) target;
		
		if(curso.getId() < 0) {
			errors.rejectValue("id", "field.required");
		}
		
	}

}
