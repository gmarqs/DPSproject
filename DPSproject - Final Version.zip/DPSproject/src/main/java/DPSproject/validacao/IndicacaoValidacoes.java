package DPSproject.validacao;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import DPSproject.models.Indicacao;

public class IndicacaoValidacoes implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		
		return Indicacao.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		//ValidationUtils.rejectIfEmpty(errors, "encaminhamento", "field.required");
		//ValidationUtils.rejectIfEmpty(errors, "localizacaoDoProblema", "field.required");
	}
	

}
