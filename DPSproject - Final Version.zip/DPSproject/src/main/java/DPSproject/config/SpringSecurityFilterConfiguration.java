/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe de configuração do Spring.
 */

package DPSproject.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringSecurityFilterConfiguration extends AbstractSecurityWebApplicationInitializer {

}
