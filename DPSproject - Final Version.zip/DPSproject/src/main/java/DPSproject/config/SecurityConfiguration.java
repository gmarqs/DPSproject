/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Classe de configuração do SpringSecurity.
 */

package DPSproject.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import DPSproject.dao.ProfessorDAO;


@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private ProfessorDAO professorDAO;
	
	/**
	 * Método utilizado para configurar a permissão de acesso as páginas.
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		   http.authorizeRequests()
		    .antMatchers("/resources/**").permitAll()
		    .antMatchers("/img/**").permitAll()
		    .antMatchers("/js/**").permitAll()
		    .antMatchers("/home/**").hasAnyRole("ADMIN,USER")
		    .antMatchers(HttpMethod.GET,"/aluno").hasAnyRole("ADMIN,USER")
		    .antMatchers(HttpMethod.POST,"/aluno").hasAnyRole("ADMIN,USER")
		    .antMatchers(HttpMethod.GET, "/login/cadastrar").hasRole("ADMIN")
		    .antMatchers(HttpMethod.POST, "/login/cadastraProfessor").hasRole("ADMIN")
		    .antMatchers(HttpMethod.POST,"/login").permitAll()
		    .antMatchers("/login/**").permitAll()
		    .antMatchers(HttpMethod.GET, "/professor").hasAnyRole("ADMIN,USER")
		    .antMatchers("/professor/editar").hasAnyRole("ADMIN,USER")
		    .antMatchers(HttpMethod.POST,"/professor/editar").hasAnyRole("ADMIN,USER")
		    .antMatchers(HttpMethod.GET,"/professor/editarSenha").hasAnyRole("ADMIN,USER")
		    .antMatchers(HttpMethod.POST,"/professor/editarSenha").hasAnyRole("ADMIN,USER")
		    .antMatchers("/professor/verConsultas").hasAnyRole("ADMIN,USER")
		    .antMatchers("/professor/resetSenha").hasAnyRole("ADMIN,USER")
		    .antMatchers("/professor/**").permitAll()
		    .antMatchers("/aluno/perfilAluno").hasAnyRole("ADMIN,USER")
		    .antMatchers("/aluno/retornaAlunos").hasAnyRole("ADMIN,USER")
		    .antMatchers("/aluno/prontuario").hasAnyRole("ADMIN,USER")
		    .antMatchers("/aluno/editarAluno").hasAnyRole("ADMIN,USER")
		    .antMatchers("/aluno/**").permitAll()
		    .antMatchers(HttpMethod.POST, "/prontuario").hasAnyRole("ADMIN,USER")
		    .antMatchers("/prontuario/visualizaProntuario").hasAnyRole("ADMIN,USER")
		    .antMatchers("/prontuario/**").permitAll()
		    .antMatchers("/home/pesquisaAluno").hasAnyRole("ADMIN,USER")
		    /*.antMatchers(HttpMethod.GET,"/home").hasRole("ADMIN")
		    .antMatchers(HttpMethod.GET,"/home").hasRole("USER")
		    .antMatchers(HttpMethod.POST,"/home").hasRole("ADMIN")
		    .antMatchers(HttpMethod.POST,"/home").hasRole("USER")*/
		    .anyRequest().authenticated()
		    .and().formLogin().loginPage("/login").successHandler(new CustomLoginSucessConfiguration()).permitAll()
		    .and().logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"));
		   
		   http.csrf()
		     .csrfTokenRepository(csrfTokenRepository());
	}
	
	/**
	 * Método de configuração da Criptografia de senhas.
	 */
	@Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(professorDAO)
        .passwordEncoder(new BCryptPasswordEncoder());
    }
	
	
	private CsrfTokenRepository csrfTokenRepository() 
	{ 
	    HttpSessionCsrfTokenRepository repository = new HttpSessionCsrfTokenRepository(); 
	    repository.setSessionAttributeName("_csrf");
	    return repository; 
	}
	
}


