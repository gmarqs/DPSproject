/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * 
 * No projeto, foi utilizado o sistema da Amazon para guardar o Banco de Dados. 
 * Porém, como é um sistema pago e não manteremos mais o projeto em Produção, passando
 * o projeto para a Unisantos, essa classe deverá ser mantida comentada, pois não terá
 * mais utilidade.
 * 
 *  Configurações utilizadas com base na Amazon. Não é padrão, cada um tem uma
 *  configuração diferente.
 * 
 */

package DPSproject.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

@Configuration
public class AmazonConfiguration {
	
	private static final String ACCESS_KEY = "AKIARDBPZLXO27SXBIBF";
	private static final String SECRET_KEY = "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";
	private static final String REGION     = "us-east-1";
	
	@Bean
	public BasicAWSCredentials basicAWSCredentials() {
	    return new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);
	}
	
	
	@Bean
	public AmazonS3 amazonS3() {
	    return AmazonS3ClientBuilder.standard().withRegion(REGION)
	            .withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials())).build();
	}
	

}
