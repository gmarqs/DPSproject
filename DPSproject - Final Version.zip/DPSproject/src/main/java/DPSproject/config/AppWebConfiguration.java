/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe de configuração do Spring.
 */

package DPSproject.config;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.guava.GuavaCacheManager;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Profile;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.format.datetime.DateFormatter;
import org.springframework.format.datetime.DateFormatterRegistrar;
import org.springframework.format.support.DefaultFormattingConversionService;
import org.springframework.format.support.FormattingConversionService;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.google.common.cache.CacheBuilder;

import DPSproject.controllers.LoginController;
import DPSproject.dao.AlunoDAO;
import DPSproject.models.FileSaver;
@EnableWebMvc
@EnableCaching
@ComponentScan(basePackageClasses={LoginController.class, AlunoDAO.class,FileSaver.class})
@EnableTransactionManagement(proxyTargetClass=true)
public class AppWebConfiguration extends WebMvcConfigurerAdapter {
	@Bean
	public InternalResourceViewResolver internalResourceViewResolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		return resolver;
	
	}
	
	@Bean
	public MessageSource messageSource(){
	    ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
	    messageSource.setBasename("/WEB-INF/messages");
	    //messageSource.setBasename("/WEB-INF/messages2");
	    messageSource.setDefaultEncoding("UTF-8");
	    messageSource.setCacheSeconds(1);
	    return messageSource;

}
	
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
	    configurer.enable();
	}
	
	@Override
    public void addResourceHandlers(final ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
        registry.addResourceHandler("/img/**").addResourceLocations("resources/img/");
        registry.addResourceHandler("/js/**").addResourceLocations("resources/js/");
    }
	
	@Bean
	public FormattingConversionService mvcConversionService() {
	    DefaultFormattingConversionService conversionService = 
	        new DefaultFormattingConversionService();
	    DateFormatterRegistrar registrar = new DateFormatterRegistrar();
	    registrar.setFormatter(new DateFormatter("dd/MM/yyyy"));
	    registrar.registerFormatters(conversionService);

	    return conversionService;
	}
	
	@Bean
    public CacheManager cacheManager(){
      CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder().maximumSize(100).expireAfterAccess(10, TimeUnit.MINUTES);
      GuavaCacheManager manager = new GuavaCacheManager();
      manager.setCacheBuilder(builder);
      return manager;
    }
	
	    @Bean
	    public MultipartResolver multipartResolver(){
	        return new StandardServletMultipartResolver();
	    }
	    
	    @Bean
	    public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource, 
	            Properties additionalProperties) {

	        LocalContainerEntityManagerFactoryBean factoryBean = 
	            new LocalContainerEntityManagerFactoryBean();
	        factoryBean.setPackagesToScan("DPSproject.models");
	        factoryBean.setDataSource(dataSource);

	        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
	        factoryBean.setJpaVendorAdapter(vendorAdapter);
	        factoryBean.setJpaProperties(additionalProperties);

	        return factoryBean;
	    }
	    
	    @Bean
	    @Profile("dev")
	    public Properties additionalProperties() {
	        Properties props = new Properties();
	        props.setProperty("hibernate.dialect", 
	            "org.hibernate.dialect.MySQL5Dialect");
	        props.setProperty("hibernate.show_sql", "true");
	        props.setProperty("hibernate.hbm2ddl.auto", "update");

	        return props;
	    }
	
	
	

}