/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe responsável por fazer a conexão com o banco de dados.
 * No caso do projeto inicial, foi utilizado o AWS da Amazon, onde o banco de dados estava
 * na núvem. 
 * Será necessário configurar essa classe para o novo banco de dados que será implementado.
 * 
 */

package DPSproject.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableTransactionManagement
public class JPAConfiguration {

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource,
			Properties additionalProperties) {
		LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
		factoryBean.setPackagesToScan("DPSproject.models");
		factoryBean.setDataSource(dataSource);

		JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		factoryBean.setJpaVendorAdapter(vendorAdapter);
		factoryBean.setJpaProperties(additionalProperties);

		return factoryBean;
	}

	@Bean
	public Properties additionalProperties() {
		Properties props = new Properties();
		props.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		props.setProperty("hibernate.show_sql", "true");
		props.setProperty("hibernate.hbm2ddl.auto", "update");
		return props;
	}
	
	/**
	 * Podemos verificar o dataSource.setUrl(), onde está setando o link de conexão com
	 * o banco que está na AWS.
	 * Será necessário fazer uma nova configuração, setando um novo link para o novo banco
	 * @return
	 */
	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setUsername("dpsproject");
		dataSource.setPassword("dpsproject");
		dataSource.setUrl("jdbc:mysql://dpsproject.cl6c2xqawxbg.us-east-1.rds.amazonaws.com:3306/dpsproject");
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		return dataSource;
	}

//	@Bean
//	@Profile("prod")
//	public DataSource dataSourceProd() {
//		DriverManagerDataSource dataSource = new DriverManagerDataSource();
//		dataSource.setUsername("root");
//		dataSource.setPassword("91971800");
//		dataSource.setUrl("jdbc:mysql://banco-dpsproject.cl6c2xqawxbg.us-east-1.rds.amazonaws.com:3306/dpsproject");
//		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
//		return dataSource;
//	}
	
	@Bean
	public JpaTransactionManager transactionManager(EntityManagerFactory emf) {
		return new JpaTransactionManager(emf);
	}

    
}