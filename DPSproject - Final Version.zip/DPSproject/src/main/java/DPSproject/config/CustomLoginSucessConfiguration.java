/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe que faz o redicionamento para tal view após o login.
 */

package DPSproject.config;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;

@Configuration
public class CustomLoginSucessConfiguration extends SimpleUrlAuthenticationSuccessHandler{
	
	
	protected void handle(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException {
		
		response.setStatus(HttpServletResponse.SC_OK);
		
		response.sendRedirect("home");
		
	}

}
