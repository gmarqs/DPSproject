/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe que organiza todas as funções disponíveis na tela home.
 */

package DPSproject.controllers;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import DPSproject.dao.AgendaDAO;
import DPSproject.dao.CursoDAO;
import DPSproject.dao.ProfessorDAO;
import DPSproject.models.Agenda;
import DPSproject.models.LocalizacaoProblema;
import DPSproject.models.Professor;

@Controller
@RequestMapping("/home")
public class HomeController {

	@Autowired
	private CursoDAO cursoDAO;

	@Autowired
	private ProfessorDAO professorDAO;

	@Autowired
	private AgendaDAO a;
	
	
/**
 * Método que recebe os dias e o horáro selecionado pelo @Professor disponíveis para consulta.
 * @param horario
 * @param dias
 * @return String
 */
	@RequestMapping(method = RequestMethod.POST)
	public String agenda(int horario, Integer[] dias) {
		Agenda agenda = null;
		Professor professor = professorDAO.BuscaProfessorEmail(SecurityContextHolder.getContext().getAuthentication().getName());
		for (int j = 0; j < dias.length; j++) {
			agenda = a.retornaAgenda(dias[j], professor.getId());
			agenda.addHorario(horario);
			a.merge(agenda);
		}
		
		
		return "redirect:/login";
	}

	/**
	 * Método que chama a tela inicial do DPSproject.
	 * @return ModelAndView
	 */
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView chamaAgenda() {
		ModelAndView mav = new ModelAndView("horarios");
		return mav;

	}
	
	
	public void calendario() {
		Calendar c = Calendar.getInstance();
		
		
		
	}

}
