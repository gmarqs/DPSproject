/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe que reune os métodos relacionados ao Login.
 * 
 */

package DPSproject.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import DPSproject.dao.AlunoDAO;
import DPSproject.dao.CursoDAO;
import DPSproject.dao.EnderecoDAO;
import DPSproject.dao.ProfessorDAO;
import DPSproject.models.Endereco;
import DPSproject.models.Professor;
import DPSproject.models.Roles;
import DPSproject.validacao.AlunoValidacoes;
import DPSproject.validacao.EnderecoValidacoes;
import DPSproject.validacao.LoginValidacoes;

@Controller
@RequestMapping("/login")
public class LoginController {
	@Autowired
	private ProfessorDAO p;

	@Autowired
	private EnderecoDAO e;

	@Autowired
	private CursoDAO c;

	@Autowired
	private AlunoDAO a;

	/**
	 * 
	 * @param binder {@link LoginValidacoes} Método que faz as ligações de validação
	 *               de campo dos formulários com a tag form:errors.
	 */
	@InitBinder("professor")
	public void initProfessorBinder(WebDataBinder binder) {
		binder.setValidator(new LoginValidacoes());

	}

	/**
	 * 
	 * @param binder {@link EnderecoValidacoes} Método que faz as ligações de
	 *               validação de campo dos formulários com a tag form:errors.
	 */
	@InitBinder("endereco")
	public void initEnderecoBinder(WebDataBinder binder) {
		binder.setValidator(new EnderecoValidacoes());

	}

	/**
	 * Método que chama a tela de login do sistema.
	 * 
	 * @return String
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String login2() {
		// c.criaCursos();
		// a.criaDias();
		return "login";

	}

	/**
	 * Método que chama a view "cadastro", responsável por fazer o cadastro de
	 * um @Professor.
	 * 
	 * @param produto
	 * @param endereco
	 * @return ModelAndView
	 */
	@RequestMapping("/cadastrar")
	public ModelAndView cadastrar(Professor produto, Endereco endereco) {
		ModelAndView mav = new ModelAndView("cadastro");
		return mav;
	}

	/**
	 * Método que é chamado pela View "cadastro" para salvar o cadastro
	 * do @Professor, via POST.
	 * 
	 * @param endereco
	 * @param br2
	 * @param professor
	 * @param br
	 * @param confirmaSenha
	 * @param rd
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/cadastraProfessor", method = RequestMethod.POST)
	public ModelAndView cadastraProfessor(@Valid Endereco endereco, BindingResult br2, @Valid Professor professor,
			BindingResult br, String confirmaSenha, RedirectAttributes rd) {
		if (br.hasErrors()) {
			return cadastrar(professor, endereco);
		}

		if (br2.hasErrors()) {
			return cadastrar(professor, endereco);

		}

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		if (professor.getSenha().equals(confirmaSenha)) {
			professor.setSenha(passwordEncoder.encode(professor.getSenha()));

			p.cadastrarProfessor(professor);
			e.cadastraEndereco(endereco);
			p.vinculaEndereco(professor, endereco);
			e.vinculaProfessor(professor, endereco);
			p.vinculaRoles(professor);
			p.criaAgendas(professor);

			ModelAndView mav2 = new ModelAndView("redirect:/home");
			return mav2;

		} else {
			ModelAndView mav2 = new ModelAndView("redirect:home");
			rd.addFlashAttribute("falha", "Falha ao cadastrar");
			return mav2;

		}

	}

	@RequestMapping("/criaAdmin")
	public String UrlMagica() {
		Professor professor = new Professor();
		Roles role = new Roles();
		role.setNome("ROLE_ADMIN");
		p.criaRole(role);
		Roles role2 = new Roles();
		role.setNome("ROLE_USER");
		p.criaRole(role);

		return "login";

	}

}
