/**
 * @author Gabriel Marques
 * @author Guiherme Watanabe
 * 
 * Controller que possui todas as ações do sistemas relacionados ao @Aluno
 * 
 */

package DPSproject.controllers;

import java.util.Arrays;
import java.util.Calendar;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import DPSproject.dao.AlunoDAO;
import DPSproject.dao.CursoDAO;
import DPSproject.dao.EnderecoDAO;
import DPSproject.dao.IndicacaoDAO;
import DPSproject.dao.ProntuarioDAO;
import DPSproject.models.Aluno;
import DPSproject.models.Curso;
import DPSproject.models.Endereco;
import DPSproject.models.Indicacao;
import DPSproject.models.LocalizacaoProblema;
import DPSproject.models.Prontuario;
import DPSproject.validacao.AlunoValidacoes;
import DPSproject.validacao.EnderecoValidacoes;
import DPSproject.validacao.IndicacaoValidacoes;

@Controller
@RequestMapping("/aluno")
public class AlunoController {

	/**
	 * 
	 * @param binder
	 * {@link AlunoValidacoes}
	 * Método que faz as ligações de validação de campo dos formulários com a tag form:errors.
	 */
	@InitBinder("aluno")
	public void initAlunoBinder(WebDataBinder binder) {
		binder.setValidator(new AlunoValidacoes());

	}
	/**
	 * 
	 * @param binder
	 * {@link EnderecoValidacoes}
	 * Método que faz as ligações de validação de campo dos formulários com a tag form:errors.
	 */
	@InitBinder("endereco")
	public void initEnderecoBinder(WebDataBinder binder) {
		binder.setValidator(new EnderecoValidacoes());

	}
	/**
	 * 
	 * @param binder
	 * {@link IndicacaoValidacoes}
	 * Método que faz as ligações de validação de campo dos formulários com a tag form:errors.
	 */
	@InitBinder("indicacao")
	public void initIndicacaoBinder(WebDataBinder binder) {
		binder.setValidator(new IndicacaoValidacoes());

	}

	@Autowired
	private CursoDAO cursoDAO;

	@Autowired
	private EnderecoDAO enderecoDAO;

	@Autowired
	private AlunoDAO alunoDAO;

	@Autowired
	private IndicacaoDAO indicacaoDAO;

	@Autowired
	private ProntuarioDAO prontuarioDAO;
	
/**
 * Método que chama a view formulario, view de cadastro de @Aluno.
 * @param aluno
 * @param endereco
 * @param indicacao
 * @return ModelAndView
 * 
 * 
 */
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView cadastraAluno(Aluno aluno, Endereco endereco, Indicacao indicacao) {
		ModelAndView mav = new ModelAndView("formulario");
		mav.addObject("lista", cursoDAO.lista());
		return mav;
	}

	/**
	 * * Método que recebe os dados da view de "formulario", que é o cadastro do @Aluno.
	 * @param aluno
	 * @param br
	 * @param number
	 * @param endereco
	 * @param br2
	 * @param indicacao
	 * @param br3
	 * @param problemas
	 * @param encaminhamento
	 * @param rd
	 * @return ModelAndView
	 * 
	 */
	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView recebe(@Valid Aluno aluno, BindingResult br, int number, @Valid Endereco endereco,
			BindingResult br2, @Valid Indicacao indicacao, BindingResult br3, String[] problemas,
			String[] encaminhamento, RedirectAttributes rd) {
		if (br.hasErrors() || br2.hasErrors() || br3.hasErrors()) {
			return cadastraAluno(aluno, endereco, indicacao);
		}

		indicacao.addProblema(Arrays.asList(problemas));
		indicacao.addEncaminhamento(Arrays.asList(encaminhamento));

		indicacaoDAO.cadastrarIndicacao(indicacao);
		enderecoDAO.cadastraEndereco(endereco);
		alunoDAO.cadastrarAluno(aluno);
		alunoDAO.vinculaEndereco(aluno, endereco);
		alunoDAO.vinculaIndicacao(aluno, indicacao);
		Curso curso = cursoDAO.pegaCurso(number);
		alunoDAO.vinculaCurso(aluno, curso);
		// enderecoDAO.vinculaAluno(aluno, endereco);
		indicacaoDAO.vinculaAluno(aluno, indicacao);

		rd.addFlashAttribute("aluno", aluno);

		ModelAndView mav2 = new ModelAndView("redirect:/prontuario");
		return mav2;

	}

	/**
	 * Método que chama a view "perfilAluno", view para pesquisar um @Aluno pela sua matrícula.
	 * @param matricula
	 * @return ModelAndView
	 * 
	 * 
	 */
	@RequestMapping("/perfilAluno")
	public ModelAndView perfilAluno(String matricula) {

		Aluno aluno = alunoDAO.BuscaAlunoMatricula(matricula);
		ModelAndView mav = new ModelAndView("perfilAluno");
		mav.addObject("lista", prontuarioDAO.retornaProntuarios(matricula));
		mav.addObject("aluno", aluno);

		return mav;

	}
	
	/**
	 *  Método que faz a busca avançada, onde mostra todos os alunos de um determinado curso e/ou problema.
	 * @return ModelAndView
	 * 
	 *
	 */
	@RequestMapping("/pesquisaAluno")
	public ModelAndView PesquisaAluno() {
		ModelAndView mav = new ModelAndView("pesquisaAluno");
		mav.addObject("tipos", LocalizacaoProblema.values());
		mav.addObject("cursos", cursoDAO.lista());
		return mav;

	}
/**
 * Método que recebe os dados da view "pesquisaAluno".
 * @param problema
 * @param cursoId
 * @return ModelAndView
 * 
 *
 */
	@RequestMapping("/retornaAlunos")
	public ModelAndView retornaAlunos(String problema, int cursoId) {
		LocalizacaoProblema lp = null;
		for (LocalizacaoProblema variavel : LocalizacaoProblema.values()) {
			if (variavel.name().equals(problema)) {
				lp = variavel;
				break;
			}
		}

		ModelAndView mav = new ModelAndView("mostraAlunos");
		mav.addObject("lista", alunoDAO.buscaAlunosCurso(lp, cursoId));

		return mav;
	}

	/**
	 * Método que chama a view de prontuário (Sintese e Orientação) pelo perfil do Aluno.
	 * @param prontuario
	 * @param id
	 * @return ModelAndView
	 */
	@RequestMapping("/prontuario")
	public ModelAndView chamaProntuarioViaPerfil(Prontuario prontuario, int id) {
		ModelAndView mav = new ModelAndView("prontuario");
		Aluno aluno = alunoDAO.BuscaAluno(id);
		mav.addObject("aluno", aluno);
		mav.addObject("data", Calendar.getInstance().getTime());
		return mav;

	}

	/**
	 * Método que chama a view "editarAluno", que permite a edição de alguns dados do @Aluno.
	 * @param id
	 * @param aluno
	 * @param endereco
	 * @return
	 */
	@RequestMapping(value = "/editarAluno", method = RequestMethod.GET)
	public ModelAndView editarAluno(int id, Aluno aluno, Endereco endereco) {
		ModelAndView mav = new ModelAndView("editarAluno");
		mav.addObject("aluno", alunoDAO.BuscaAluno(id));
		mav.addObject("lista", cursoDAO.lista());
		mav.addObject("endereco", alunoDAO.BuscaAluno(id).getEndereco());

		return mav;
	}

	/**
	 * Método que recebe os dados da view "editarAluno", via POST.
	 * @param aluno
	 * @param br
	 * @param endereco
	 * @param br2
	 * @param idaluno
	 * @param idend
	 * @param number
	 * @return
	 */
	@RequestMapping(value = "/editarAluno", method = RequestMethod.POST)
	public ModelAndView editarAluno(@Valid Aluno aluno, BindingResult br, @Valid Endereco endereco, BindingResult br2,
			int idaluno, int idend, int number) {
		Aluno a = alunoDAO.BuscaAluno(idaluno);
		a.setTelefone(aluno.getTelefone());
		a.setPeriodo(aluno.getPeriodo());
		a.setCurso(cursoDAO.pegaCurso(number));
		alunoDAO.merge(a);
		endereco.setId(idend);
		enderecoDAO.merge(endereco);
		
		return new ModelAndView("redirect:/home");

	}

}