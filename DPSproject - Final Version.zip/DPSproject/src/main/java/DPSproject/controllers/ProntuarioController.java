/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe que reune todos os métodos relacionados ao Prontuário.
 * 
 */

package DPSproject.controllers;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import DPSproject.dao.AlunoDAO;
import DPSproject.dao.ProntuarioDAO;
import DPSproject.models.Aluno;
import DPSproject.models.FileSaver;
import DPSproject.models.Prontuario;
import DPSproject.validacao.LoginValidacoes;
import DPSproject.validacao.ProntuarioValidacoes;

@Controller
@RequestMapping("/prontuario")
public class ProntuarioController {

	@Autowired
	private ProntuarioDAO p;

	@Autowired
	private AlunoDAO alunoDAO;

	@Autowired
	private FileSaver fileSaver;

	/**
	 * 
	 * @param binder {@link ProntuarioValidacoes} Método que faz as ligações de validação
	 *               de campo dos formulários com a tag form:errors.
	 */
	@InitBinder("prontuario")
	public void initProntuarioBinder(WebDataBinder binder) {
		binder.setValidator(new ProntuarioValidacoes());

	}

	/**
	 * Método chamado após cadastrar um aluno (Sintese e Orientação). Realiza o 
	 * acompanhamento da consulta.
	 * @param prontuario
	 * @return ModelAndView
	 */
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView chamaProntuario(Prontuario prontuario) {
		ModelAndView mav = new ModelAndView("prontuario");
		mav.addObject("data", Calendar.getInstance().getTime());
		return mav;
	}

	/**
	 * Método que salva o prontuário. Via POST.
	 * @param sumario
	 * @param prontuario
	 * @param br
	 * @param identificador
	 * @return
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView cadastraProntuario(MultipartFile sumario, @Valid Prontuario prontuario, BindingResult br,
			int identificador) throws IllegalStateException, IOException {
		if (br.hasErrors()) {
			return chamaProntuario(prontuario);

		}
		System.out.println(sumario.getOriginalFilename());

		String path = fileSaver.write(sumario);

		prontuario.setSumarioPath(path);
		System.out.println(prontuario);
		Aluno aluno = alunoDAO.BuscaAluno(identificador);
		p.vinculaAluno(prontuario, aluno);
		prontuario.setData(toCalendar(Calendar.getInstance().getTime()));
		p.cadastraProntuario(prontuario);

		ModelAndView mav = new ModelAndView("redirect:/home");
		return mav;

	}

	public static Calendar toCalendar(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal;
	}

	/**
	 * Método que chama a view "visualizaProntuario", para visualizar todos os prontuários
	 * de um determinado aluno. Opção está localizada no perfil do aluno.
	 * @param id
	 * @return
	 */
	@RequestMapping("/visualizaProntuario")
	public ModelAndView visualizaProntuario(int id) {
		ModelAndView mav = new ModelAndView("visualizaProntuario");
		mav.addObject("prontuario", p.chamaProntuario(id));

		return mav;
	}

}
