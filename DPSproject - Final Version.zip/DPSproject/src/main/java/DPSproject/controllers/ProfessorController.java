/**
 * @author Gabriel Marques
 * @author Guilherme Watanabe
 * 
 * Classe que reune todos os métodos relacionados ao Professor.
 * 
 */

package DPSproject.controllers;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import DPSproject.dao.AgendaDAO;
import DPSproject.dao.EnderecoDAO;
import DPSproject.dao.ProfessorDAO;
import DPSproject.models.Agenda;
import DPSproject.models.Consulta;
import DPSproject.models.Endereco;
import DPSproject.models.Professor;

@Controller
@RequestMapping("/professor")
public class ProfessorController {

	@Autowired
	private ProfessorDAO p;

	@Autowired
	private EnderecoDAO e;

	@Autowired
	private AgendaDAO a;

	/**
	 * Método que chama a view "listaProfessores", que mostra todos os @Professor
	 * cadastrados.
	 * 
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView editarProfessor() {
		ModelAndView mav = new ModelAndView("listaProfessores");
		mav.addObject("lista", p.buscaProfessores());

		return mav;

	}

	/**
	 * Método que chama a view "editarProfessor", que permite ao professor realizar
	 * a edição do seu cadastro
	 * 
	 * @param professor
	 * @param endereco
	 * @return ModelAndView
	 */
	@RequestMapping("/editar")
	public ModelAndView editarProfessor(Professor professor, Endereco endereco) {
		ModelAndView mav = new ModelAndView("editarProfessor");
		Professor prof = p.BuscaProfessorEmail(SecurityContextHolder.getContext().getAuthentication().getName());
		mav.addObject("professor", prof);
		mav.addObject("endereco", e.getEndereco(p.getProfessor(prof.getId()).getEndereco().getId()));

		return mav;
	}

	/**
	 * Método que salva as informações da edição do professor, via POST.
	 * 
	 * @param professor
	 * @param br
	 * @param endereco
	 * @param br2
	 * @param senha
	 * @param confirmaSenha
	 * @param idprof
	 * @param idend
	 * @param rd
	 * @return ModelAndView
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/editar")
	public ModelAndView editarProfessor(Professor professor, BindingResult br, Endereco endereco, BindingResult br2,
			String senha, String confirmaSenha, int idprof, int idend, RedirectAttributes rd) {

		Professor prof = p.getProfessor(idprof);
		prof.setEmail(professor.getEmail());
		prof.setNumeroMatricula(professor.getNumeroMatricula());
		p.merge(prof);
		endereco.setProfessor(prof);
		endereco.setId(idend);
		e.merge(endereco);

		ModelAndView mav = new ModelAndView("redirect:/login");

		return mav;
	}

	/**
	 * Método que salva a nova senha do Professor, via POST.
	 * 
	 * @param senhaAntiga
	 * @param novaSenha
	 * @param confirmaSenha
	 * @param id
	 * @return ModelAndView
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/editarSenha")
	public ModelAndView editarSenha(String senhaAntiga, String novaSenha, String confirmaSenha, int id) {
		Professor professor = p.getProfessor(id);
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		if (!passwordEncoder.matches(senhaAntiga, professor.getSenha())) {
			ModelAndView mav = new ModelAndView("editarSenha");
			mav.addObject("mensagem", "Senha incorreta! Favor verificar.");
			return mav;
		}

		if (!novaSenha.equals(confirmaSenha)) {
			ModelAndView mav = new ModelAndView("editarSenha");
			mav.addObject("mensagem", "Sua nova senha precisa ser igual ao campo de confirmação");
			return mav;
		}
		professor.setSenha(passwordEncoder.encode(novaSenha));
		p.merge(professor);
		ModelAndView mav = new ModelAndView("redirect:/logout");
		return mav;
	}

	/**
	 * Método que chama a view "editarSenha", que permite ao professor editar a sua
	 * senha.
	 * 
	 * @return ModelAndView
	 */
	@RequestMapping(method = RequestMethod.GET, value = "editarSenha")
	public ModelAndView editarSenha() {
		ModelAndView mav = new ModelAndView("editarSenha");
		mav.addObject("professor",
				p.BuscaProfessorEmail(SecurityContextHolder.getContext().getAuthentication().getName()));

		return mav;
	}

	/**
	 * Método que chama a view "selecionaProf", que permite ao usuário selecionar um
	 * professor para marcar uma consulta.
	 * 
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/consulta2", method = RequestMethod.GET)
	public ModelAndView consulta() {
		ModelAndView mav = new ModelAndView("selecionaProf");
		mav.addObject("lista", p.getProfessores());

		return mav;

	}

	/**
	 * Método que chama a view "marca-consulta", que mostra os dias e horários disponíveis
	 * para o usuário marcar uma consulta.
	 * @param consulta
	 * @param number
	 * @return ModelAndView
	 */
	@RequestMapping("/seleciona")
	public ModelAndView selecionado(Consulta consulta, int number) {
		ModelAndView mav = new ModelAndView("marca-consulta");

		mav.addObject("professor", p.getProfessor(number));
		mav.addObject("segunda", a.getSegunda(number));
		mav.addObject("terca", a.getTerca(number));
		mav.addObject("quarta", a.getQuarta(number));
		mav.addObject("quinta", a.getQuinta(number));
		mav.addObject("sexta", a.getSexta(number));
		mav.addObject("sabado", a.getSabado(number));

		return mav;
	}

	/**
	 * Método que salva as informações da consulta marcada pelo usuário, via POST.
	 * @param consulta
	 * @param prof
	 * @return String
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/consulta")
	public String consulta2(Consulta consulta, Integer prof) {
		consulta.setDiaDaSemana(consulta.getData().get(Calendar.DAY_OF_WEEK));
		consulta.setProfessor(p.getProfessor(prof));
		consulta.setStatus("Ativo");
		p.cadastraConsulta(consulta);
		Agenda agenda = a.retornaAgenda(consulta.getDiaDaSemana(), prof);
		agenda.addConsulta(consulta);
		a.merge(agenda);

		return "redirect:/home";

	}

	/**
	 * Método que recebe o id do Professor e realiza a exclusão do mesmo do sistema.
	 * @param id
	 * @return String
	 */
	@RequestMapping("/excluir")
	public String excluir(int id) {
		p.excluirProfessor(id);

		return "redirect:/home";
	}

	/**
	 * Método que reseta a senha do professor para "Mudar123". Só professores cadastraados
	 * como "ADMIN" poderão resetar a senha de outros professores.
	 * @param id
	 * @return String
	 */
	@RequestMapping("/resetSenha")
	public String resetSenha(int id) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		Professor professor = p.getProfessor(id);
		professor.setSenha(passwordEncoder.encode("Mudar123"));
		p.merge(professor);

		return "horarios";
	}

	/**
	 * Método que chama a view "verConsultas", mostra todas as consultas marcadas para os próximos dias.
	 * @return ModelAndView
	 */
	@RequestMapping("/verConsultas")
	public ModelAndView verConsultas() {
		ModelAndView mav = new ModelAndView("verConsultas");
		mav.addObject("consultas", a
				.getConsultas(p.BuscaProfessorEmail(SecurityContextHolder.getContext().getAuthentication().getName())));

		return mav;
	}

	/**
	 * Método que realiza o cancelamento de uma consulta, por parte do professor.
	 * @param id
	 * @return String
	 */
	@RequestMapping("/excluirConsulta")
	public String excluirConsulta(int id) {

		Consulta consulta = a.getConsulta(id);
		consulta.setStatus("Cancelada");
		a.mergeConsulta(consulta);

		return "redirect:/home";

	}

}
